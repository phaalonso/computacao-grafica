#ifndef PHDESENHOBASICO_INCLUDE
#define PHDESENHOBASICO_INCLUDE

void phDesenharEsfera(int raio);

#endif