#ifndef PHDESENHOBASICO_INCLUDE
#define PHDESENHOBASICO_INCLUDE

void phDesenharRetangulo(float minX, float minY, float maxX, float maxY);
void phDesenhaCirculo(float x, float y, float raio);

#endif